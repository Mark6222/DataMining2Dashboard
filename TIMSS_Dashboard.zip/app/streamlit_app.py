import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

# Load the cleaned data
df = pd.read_feather('../data/cleaned_data.feather')

# Sidebar filters
st.sidebar.header('Filters')
grade = st.sidebar.selectbox('Select Grade', df['IDGRADER'].unique())
country = st.sidebar.selectbox('Select Country', df['IDCNTRY'].unique())
school = st.sidebar.selectbox('Select School', df['IDSCHOOL'].unique())

# Filter the dataframe based on selections
filtered_df = df[(df['IDGRADER'] == grade) & (df['IDCNTRY'] == country) & (df['IDSCHOOL'] == school)]

# Page selection
st.sidebar.header('Pages')
page = st.sidebar.selectbox('Select Page', ['Overview', 'Math Scores', 'Science Scores', 'Demographics'])

# Page content
if page == 'Overview':
    st.header('Overview')
    st.write(filtered_df.describe())
elif page == 'Math Scores':
    st.header('Math Scores')
    plt.figure(figsize=(10, 5))
    plt.hist(filtered_df['MATHSCORE'], bins=20, color='blue', edgecolor='black')
    plt.title('Distribution of Math Scores')
    plt.xlabel('Score')
    plt.ylabel('Frequency')
    st.pyplot(plt)
elif page == 'Science Scores':
    st.header('Science Scores')
    plt.figure(figsize=(10, 5))
    plt.hist(filtered_df['SCISCORE'], bins=20, color='green', edgecolor='black')
    plt.title('Distribution of Science Scores')
    plt.xlabel('Score')
    plt.ylabel('Frequency')
    st.pyplot(plt)
elif page == 'Demographics':
    st.header('Demographics')
    st.write(filtered_df[['IDSTUD', 'IDCLASS', 'IDSCHOOL', 'IDCNTRY', 'IDGRADER']])

